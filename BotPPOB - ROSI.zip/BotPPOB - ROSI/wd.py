#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import sys
import json
import time
import random
import logging
import subprocess
from typing import Optional, Tuple, Dict, Any, List

# =========================
# CONFIG (EDIT DI SINI)
# =========================

SOCKS_POOL = [
    "aristore:1447@idnusa.rajaserverpremium.web.id:1080",
    "aristore:1447@idnusa2.rajaserverpremium.web.id:1080",
]

SETTINGS = {
    "qris": "00020101021126670016COM.NOBUBANK.WWW01189360050300000879140214032457554842140303UMI51440014ID.CO.QRIS.WWW0215ID20254096528100303UMI5204541153033605802ID5919ROSISTORE OK24821196009BANGKALAN61056911162070703A0163049B03",
    "web_payment_getway": "api.rajaserverpremium.web.id",
    "apikey_paymet_getway": "rosistore",

    # ✅ SUDAH DIISI DARI REQUEST KAMU
    "web_mutasi": "https://app.orderkuota.com/api/v2/qris/mutasi/2482119",
    "auth_username_mutasi": "rosistore",
    "auth_token_mutasi": "2482119:YbUzFihTjel4Myr1O0KR6ZdwkDxPHntN",
}

# WD endpoint + headers “signature” (PAKAI PUNYA KAMU)
# ⚠️ Kamu belum kasih request WD-nya, jadi ini belum bisa dipastikan benar
WD_ENDPOINT = "https://app.orderkuota.com/api/v2/get"
WD_SIGNATURE = "54880eb5297a263b8f67c78c7c7460a2ee597b341dbb6931743c3208a05dc5eefcf9e394bcec6fb94510674732afbcca3bdf71b9f8c191f6263fc2d248911663"

# ✅ Param device (SUDAH DIISI DARI REQUEST KAMU)
APP_REG_ID = "eiI0ANCITsatykl2VN4O8Z:APA91bFxNAKbNNV25EUnvVJ27l0Rv9se29yc0aqwFRXTXjzIudVhW3JKZrthxl0SmrQwN7Jpb_vcOfFDjgx6uq3jTGi8bhONz0jL41Rk9vIjp9qJ2cHd14Q"
PHONE_UUID = "eiI0ANCITsatykl2VN4O8Z"
PHONE_MODEL = "25062RN2DY"
PHONE_ANDROID_VERSION = "15"
APP_VERSION_CODE = "251231"
APP_VERSION_NAME = "99.99.99"
UI_MODE = "light"

# Min WD
MIN_WD = 1000

# Logging
LOG_FILE = os.path.join(os.path.dirname(__file__), "wdqris.log")


# =========================
# UTILS
# =========================

def setup_logger() -> logging.Logger:
    logger = logging.getLogger("wdqris")
    logger.setLevel(logging.INFO)

    fmt = logging.Formatter("%(asctime)s | %(levelname)s | %(message)s")
    fh = logging.FileHandler(LOG_FILE, encoding="utf-8")
    fh.setFormatter(fmt)
    sh = logging.StreamHandler(sys.stdout)
    sh.setFormatter(fmt)

    # avoid duplicate handlers
    if not logger.handlers:
        logger.addHandler(fh)
        logger.addHandler(sh)
    return logger


def format_idr(n: int) -> str:
    s = str(int(n))
    out = []
    while s:
        out.append(s[-3:])
        s = s[:-3]
    return ".".join(reversed(out))


def build_proxy_list() -> List[Optional[str]]:
    lst = list(SOCKS_POOL)
    random.shuffle(lst)
    lst.append(None)  # fallback NO PROXY
    return lst


def run_curl(cmd: List[str], timeout_sec: int = 30) -> Tuple[str, str, int]:
    try:
        p = subprocess.run(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=timeout_sec,
            check=False,
            text=True,
        )
        return (p.stdout.strip(), p.stderr.strip(), p.returncode)
    except subprocess.TimeoutExpired:
        return ("", f"Timeout after {timeout_sec}s", 124)


def try_parse_json(s: str) -> Tuple[bool, Optional[Dict[str, Any]]]:
    try:
        return True, json.loads(s)
    except Exception:
        return False, None


def to_int_saldo(val: Any) -> int:
    if val is None:
        return 0
    if isinstance(val, (int, float)):
        return int(val)
    txt = str(val).replace(".", "").strip()
    if not txt.isdigit():
        return 0
    return int(txt)


# =========================
# CORE
# =========================

def fetch_qris_history(logger: logging.Logger, proxy: Optional[str]) -> Dict[str, Any]:
    if not SETTINGS.get("web_mutasi"):
        raise RuntimeError("settings.web_mutasi kosong")
    if not SETTINGS.get("auth_username_mutasi") or not SETTINGS.get("auth_token_mutasi"):
        raise RuntimeError("Auth mutasi kosong (auth_username_mutasi/auth_token_mutasi)")

    cmd = [
        "curl", "--silent", "--compressed",
        "--connect-timeout", "10",
        "--max-time", "20",
    ]

    # socks: format user:pass@host:port OR host:port
    if proxy:
        cmd += ["--socks5-hostname", proxy]

    cmd += [
        "-X", "POST", SETTINGS["web_mutasi"],

        # ✅ header sesuai request kamu
        "-H", "Content-Type: application/x-www-form-urlencoded",
        "-H", "Accept-Encoding: gzip",
        "-H", "User-Agent: okhttp/4.12.0",
    ]

    # ✅ body sesuai request kamu (yang penting + device info)
    cmd += [
        "--data-urlencode", f"app_reg_id={APP_REG_ID}",
        "--data-urlencode", f"phone_uuid={PHONE_UUID}",
        "--data-urlencode", f"phone_model={PHONE_MODEL}",
        "--data-urlencode", f"phone_android_version={PHONE_ANDROID_VERSION}",
        "--data-urlencode", f"app_version_code={APP_VERSION_CODE}",
        "--data-urlencode", f"app_version_name={APP_VERSION_NAME}",
        "--data-urlencode", f"ui_mode={UI_MODE}",

        "--data-urlencode", "requests[0]=account",
        "--data-urlencode", "requests[qris_history][page]=1",
        "--data-urlencode", "requests[qris_history][keterangan]=",
        "--data-urlencode", "requests[qris_history][jumlah]=",
        "--data-urlencode", "requests[qris_history][dari_tanggal]=",
        "--data-urlencode", "requests[qris_history][ke_tanggal]=",

        "--data-urlencode", f"auth_username={SETTINGS['auth_username_mutasi']}",
        "--data-urlencode", f"auth_token={SETTINGS['auth_token_mutasi']}",
        "--data-urlencode", f"request_time={int(time.time() * 1000)}",
    ]

    out, err, code = run_curl(cmd, timeout_sec=30)
    if not out:
        raise RuntimeError(f"History empty output (code={code}) err={err[:200]}")

    ok, data = try_parse_json(out)
    if not ok or data is None:
        raise RuntimeError(f"History bukan JSON: {out[:200]}")

    return data


def withdraw_qris(logger: logging.Logger, proxy: Optional[str], amount: int) -> Dict[str, Any]:
    ts = str(int(time.time() * 1000))

    cmd = [
        "curl", "--silent", "--compressed",
        "--connect-timeout", "8",
        "--max-time", "20",
    ]

    if proxy:
        cmd += ["--socks5-hostname", proxy]

    cmd += [
        "-X", "POST", WD_ENDPOINT,
        "-H", f"signature: {WD_SIGNATURE}",
        "-H", f"timestamp: {ts}",
        "-H", "Content-Type: application/x-www-form-urlencoded",
        "-H", "Accept-Encoding: gzip",
        "-H", "User-Agent: okhttp/4.12.0",
        "--data-urlencode", f"request_time={ts}",
        "--data-urlencode", f"app_reg_id={APP_REG_ID}",
        "--data-urlencode", f"phone_android_version={PHONE_ANDROID_VERSION}",
        "--data-urlencode", f"app_version_code={APP_VERSION_CODE}",
        "--data-urlencode", f"phone_uuid={PHONE_UUID}",
        "--data-urlencode", f"auth_username={SETTINGS['auth_username_mutasi']}",
        "--data-urlencode", f"auth_token={SETTINGS['auth_token_mutasi']}",
        "--data-urlencode", f"requests[qris_withdraw][amount]={amount}",
        "--data-urlencode", f"app_version_name={APP_VERSION_NAME}",
        "--data-urlencode", f"ui_mode={UI_MODE}",
        "--data-urlencode", f"phone_model={PHONE_MODEL}",
    ]

    out, err, code = run_curl(cmd, timeout_sec=30)
    if not out:
        raise RuntimeError(f"WD empty output (code={code}) err={err[:200]}")

    ok, data = try_parse_json(out)
    if not ok or data is None:
        raise RuntimeError(f"WD bukan JSON: {out[:200]}")

    return data


def is_success_wd(res: Dict[str, Any]) -> Tuple[bool, str]:
    q = (
        res.get("qris_withdraw")
        or (res.get("data") or {}).get("qris_withdraw")
        or (res.get("result") or {}).get("qris_withdraw")
        or res
    )

    if isinstance(q, dict):
        msg = q.get("message") or res.get("message") or ""
        ok = (
            q.get("success") is True
            or res.get("success") is True
            or res.get("status") == "success"
            or (res.get("meta") or {}).get("code") == 200
        )
        return ok, msg or ""
    return False, ""


def main():
    logger = setup_logger()
    logger.info("=== WD QRIS CRON START ===")

    proxy_list = build_proxy_list()

    # 1) Ambil history
    history = None
    history_proxy = None
    last_err = None

    for p in proxy_list:
        try:
            logger.info(f"[HISTORY] try via {'PROXY ' + p if p else 'NO_PROXY'}")
            history = fetch_qris_history(logger, p)
            history_proxy = p
            break
        except Exception as e:
            last_err = e
            logger.warning(f"[HISTORY] failed via {p or 'NO_PROXY'}: {e}")

    if history is None:
        logger.error(f"Gagal ambil history. Last error: {last_err}")
        sys.exit(2)

    latest = (((history.get("qris_history") or {}).get("results")) or [None])[0]
    saldo_asli = to_int_saldo((latest or {}).get("saldo_akhir"))

    jumlah = to_int_saldo((latest or {}).get("jumlah"))
    ket = (latest or {}).get("keterangan") or ""
    transaksi_log = f"Rp{format_idr(jumlah)} - {ket}" if (jumlah and ket) else "Tidak ada detail transaksi terakhir"

    logger.info(f"[SALDO] via {'PROXY' if history_proxy else 'NO_PROXY'} saldo_akhir=Rp{format_idr(saldo_asli)}")
    logger.info(f"[LAST_TX] {transaksi_log}")

    if saldo_asli < MIN_WD:
        logger.info(f"Saldo belum cukup untuk WD minimal Rp{format_idr(MIN_WD)}. STOP.")
        sys.exit(0)

    amount = (saldo_asli // 1000) * 1000
    if amount < MIN_WD:
        logger.info("Amount hasil pembulatan < MIN_WD. STOP.")
        sys.exit(0)

    # 2) WD
    wd_res = None
    wd_proxy = None
    last_wd_err = None

    for p in proxy_list:
        try:
            logger.info(f"[WD] try via {'PROXY ' + p if p else 'NO_PROXY'} amount=Rp{format_idr(amount)}")
            wd_res = withdraw_qris(logger, p, amount)
            wd_proxy = p
            break
        except Exception as e:
            last_wd_err = e
            logger.warning(f"[WD] failed via {p or 'NO_PROXY'}: {e}")

    if wd_res is None:
        logger.error(f"WD gagal semua proxy + no-proxy. Last error: {last_wd_err}")
        sys.exit(3)

    ok, msg = is_success_wd(wd_res)

    try:
        raw_str = json.dumps(wd_res, ensure_ascii=False)[:1200]
    except Exception:
        raw_str = str(wd_res)[:1200]

    if ok:
        logger.info(f"✅ WD BERHASIL DIMINTA | amount=Rp{format_idr(amount)} | via={'PROXY' if wd_proxy else 'NO_PROXY'} | msg={msg}")
        logger.info(f"[WD_RAW] {raw_str}")
        sys.exit(0)
    else:
        logger.error("❌ WD GAGAL (API response tidak success)")
        logger.error(f"amount=Rp{format_idr(amount)} saldo=Rp{format_idr(saldo_asli)} last_tx={transaksi_log}")
        logger.error(f"[WD_RAW] {raw_str}")
        sys.exit(4)


if __name__ == "__main__":
    main()
