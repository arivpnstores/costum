module.exports = {
  apps: [
    {
      name: "BotPPOB",
      script: "app.js",          // ganti kalau file utama kamu bukan app.js
      cwd: "/root/BotPPOB",
      instances: 1,
      exec_mode: "fork",
      autorestart: true,
      watch: false,              // kalau mau auto reload saat file berubah, ubah true (tapi biasanya false lebih aman di server)
      max_memory_restart: "300M",

      // biar log rapi
      out_file: "/root/BotPPOB/logs/out.log",
      error_file: "/root/BotPPOB/logs/error.log",
      log_date_format: "YYYY-MM-DD HH:mm:ss",

      // kalau kamu pakai .env (opsional)
      env: {
        NODE_ENV: "production"
      }
    }
  ]
};
